public class findingShortestPath {

    public static void shortestPath(String s, int x1, int y1) {
        double x = x1;
        double y = y1;

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == 'N') {
                y += 1;
            }
            if (s.charAt(i) == 'E') {
                x += 1;
            }
            if (s.charAt(i) == 'S') {
                y -= 1;
            }
            if (s.charAt(i) == 'W') {
                x -= 1;
            }
        }
        double dx = x - x1;
        double dy = y - y1;

        double ans = Math.sqrt((dx*dx)+(dy*dy));

        System.out.println(ans);

    }

    public static void main(String[] args) {
        String s = "WNEENESENNN";
        int x1 = 2;
        int y1 = 7;

        shortestPath(s, x1, y1);
    }
}