public class sample {

    public static void main(String[] args) {
        String s = "i";
        char c = (char)(s.charAt(0)-5);
        System.out.println(c);
    }
    
}
