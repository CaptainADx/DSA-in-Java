public class swapWithoutThirdVar {
    public static void swapping(int x, int y) {
        // This problem can be solved using XOR operation...
        x = x ^ y;
        y = x ^ y;
        x = x ^ y;

        System.out.println("New Value of X : " + x);
        System.out.println("New Value of Y : " + y);
    }

    public static void main(String[] args) {
        int x = 5;
        int y = 6;
        System.out.println("Current Value of X : " + x);
        System.out.println("Current Value of Y : " + y);

        System.out.println("-------------AFTER SWAPPING-------------");
        swapping(x, y);
    }
}
