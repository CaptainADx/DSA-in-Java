
public class bitwiseShift {
    public static void main(String[] args){


        System.out.println(5<<2); // Form of : a << b =  a * (2^b) ---> a multipled by (2 raised to the power of b).

        // We can observe that each time we perform left shift the number is Doubled its current value....

        /*
            5 << 1  = 5x2 ---> 10
            5 << 2  = 5 x 2 x 2  ---> 20
            5 << 3  = 5 x 2 x 2 x 2  ---> 40
        */

        System.out.println(5>>2); // Form of : a >> b = a / (2^b) ---> a divided by (2 raised to the power of b).
        
        // Similarly when we right shift the number is divided by 2 each time ....

        /*
            40 >> 1  = 40/2 ---> 20
            40 >> 2  = (40/2) / 2  ---> 10 
            40 >> 3  = ((40/2) / 2) / 2  ---> 5
        */
    }
}
