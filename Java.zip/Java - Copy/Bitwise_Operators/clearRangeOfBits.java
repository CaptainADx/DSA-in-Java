public class clearRangeOfBits {
    public static int clearBitsInRange(int n, int i, int j){
        int a = (~0)<<(j+1);
        int b = ~((~0)<<i);

        int bitMask = a|b;
        int nums = n & bitMask;

        return nums;
    }

    public static void main(String[] args){
        int number = 2515;
        int i = 2;
        int j = 7;
        int a = clearBitsInRange(number, i, j);
        System.out.println(a);
    }
}
