public class Getter_Setter {
    public static void main(String[] args) {
        Pen p1 = new Pen();   //Pen() is a Constructor

        p1.setColor("blue");
        System.out.println(p1.getColor());

        p1.setTip(7);
        System.out.println(p1.getTip());
    }
}

class Pen{
    private int tip;
    private String color;


    //Setter Function
    void setColor(String color){
        this.color = color;
    }

    //Getter Function
    String getColor(){               
        return this.color;
    }

    //Setter Function
    void setTip(int tip){
        this.tip = tip;
    }

    //Getter Function
    int getTip(){
        return this.tip;
    }
}
