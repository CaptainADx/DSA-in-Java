public class abstractClasses {
    public static void main(String[] args) {

        /* We cannot create an object or instance for the Abstract classes.
           But we can create the object or instance for the derived class.
        */
        Horse mustang = new Horse();      // Instance for derived class is created.  
        mustang.legs = 4;
        mustang.color = "White";          // We can overwrite the elements of constructor.
        mustang.breathe();
        System.out.println(mustang.legs);
        System.out.println(mustang.survivingYears);
    }
    
}

abstract class Animal {
    String color;
    int survivingYears;
    Animal(){               // We can create a constructor for the abstract class and it will automatically called.
        color = "Brown";
        System.out.println("Constructor is Called...");
    }
    
    void eat(){
        System.out.println("Eats Everything");
    }
    abstract void breathe();  // An abstract method must be defined in its Child class.
}

class Horse extends Animal{
    int legs;
    @Override
    void breathe() {                           // Here Abstract class breathe() is defined.
        System.out.println("Breathes");
    }
}