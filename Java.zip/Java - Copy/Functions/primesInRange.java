public class primesInRange {

    public static boolean isPrime(int num){
        boolean isPrime = true;
        if(num == 2 || num == 3){
            return isPrime;
        }
        for(int i=2; i<=Math.sqrt(num); i++){
            if(num%i == 0){
                isPrime = false;
            }
        }
        return isPrime;
    }

    public static void primeInRange(int num) {
        for(int i=2; i<=num; i++){
            if(isPrime(i)){
                System.out.print(i+ ", ");
            }
        }
    }
    public static void main(String[] args) {
        primeInRange(17);
    }
}
