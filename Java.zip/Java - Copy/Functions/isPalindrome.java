import java.util.Scanner;

// let Num = 12321

public class isPalindrome {

    public static boolean checkPalindrome(int num){
        int ans = 0;
        int num1 = num;
        while(num!=0){
            int temp = num%10;
            ans*=10;
            ans+=temp;
            num/=10;
        }
        if(ans == num1){
            return true;
        }
        else{
            return false;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();

        boolean answer = checkPalindrome(num);
        System.out.println("Palindrome ? ---> "+answer);

        sc.close();
    }
}