import java.util.*;
public class printUntil10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number;
        do{
            System.out.print("Enter your number : ");
            number = sc.nextInt();
            if(number%10 == 0){
                break;
            }
            System.out.println(number);
        }while(true);


        System.out.println("Loop exited since number is multiple of 10");


        sc.close();
        
    }
}
