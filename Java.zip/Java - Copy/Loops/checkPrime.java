
import java.util.*;

public class checkPrime {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Number --> ");
        int number = sc.nextInt();
        boolean checkPrimeNum = true;
        if (number == 2 || number == 3) {
            System.out.println("Prime Number --> " + number);
        }
        for(int i=2; i<Math.sqrt(number); i++){
            if(number%i == 0){
                checkPrimeNum = false;
                break;
            }
        }
        if(checkPrimeNum){
            System.out.println("Prime Number --> " + number);
        } 
        else{
            System.out.println("Composite Number --> " + number);
        }
        sc.close();
    }
}
