public class Q4 {
    public static void main(String[] args) {
       
        int a = 63, b = 36; 
        boolean x = (a < b ); 
        int y= (a > b ) ? a : b;    

        System.out.println(y);
        System.out.println(x);
    }
}
