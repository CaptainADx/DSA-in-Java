import java.util.*;
public class Q5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a Year to check : ");
        int year = sc.nextInt();
        if(year%4 == 0 && year%100 ==0 && year%400!=0){
            System.out.println("Not a Leap Year");
        }
        else if(year%4==0 && year%400==0){
            System.out.println("It is a Leap Year");
        }
        else if(year%4==0 && year%100 != 0){
            System.out.println("It is a Leap Year");
        }
        else{
            System.out.println("Not a Leap Year");
        }
        sc.close();
    }
}