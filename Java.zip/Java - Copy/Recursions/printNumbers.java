public class printNumbers {
    public static void main(String[] args){
        int N = 10;
        printNumbersIncreasing(N);
    }

    public static void printNumbersIncreasing(int n){
        int num = 0;
        if(num >  n){
            System.out.print(num + " ");
            return;
        }
        printNumbersIncreasing(num+1);
    }
}
