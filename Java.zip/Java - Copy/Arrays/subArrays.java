public class subArrays {

    public static void printSubArrays(int arr[]){
        int i=0;
        int maxSum=arr[i];
        int minSum=arr[i];
        for(i=0; i<arr.length; i++){
            int start = i;
            for(int j=i; j<arr.length; j++){
                int end = j;
                int temp=0;
                for(int k=start; k<=end; k++){
                    System.out.print(arr[k] + " ");
                    temp+=arr[k];
                }
                if(temp>maxSum){
                    maxSum = temp;
                }
                if(temp<minSum){
                    minSum=temp;
                }
                System.out.println();
            }
            System.out.println();
        }
        System.out.println("MAX SUM : "+maxSum);
        System.out.println("MIN SUM : "+ minSum);
    }
    public static void main(String[] args){
        int arr[]={1,-2,6,-1,3};

        printSubArrays(arr);
    }
}
