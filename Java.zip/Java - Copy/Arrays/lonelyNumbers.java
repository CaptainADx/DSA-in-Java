import java.util.ArrayList;
import java.util.Arrays;

public class lonelyNumbers {
    
    public static ArrayList<Integer> lonelyNumber_(int arr[]) {
        ArrayList<Integer> nums = new ArrayList<>();
        Arrays.sort(arr);
        for(int i=0; i<arr.length; i++){
            if(i==0){
                if(arr[i] != arr[i+1] && arr[i+1]!=arr[i]+1){
                    nums.add(arr[i]);
                }
            }
            else if(i==arr.length-1){
                if(arr[i] != arr[i-1] && arr[i-1] != arr[i]-1){
                    nums.add(arr[i]);
                }
            }
            else{
                if(arr[i] != arr[i+1] && arr[i+1] != arr[i]+1 && arr[i] != arr[i-1] && arr[i-1] != arr[i]-1){
                    nums.add(arr[i]);
                }
            }
        }
        return nums;
    }

    public static void main(String[] args){
        int[] arr = {10, 5, 6, 8};
        System.out.println(lonelyNumber_(arr));
    }
}
