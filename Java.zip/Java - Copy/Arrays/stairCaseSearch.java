public class stairCaseSearch {

    public static void findElement(int[][] matrix, int target){
        
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            System.out.println("Element Not Found");
            return;
        }

        int currRow = 0;
        int currCol = matrix[0].length-1;
        int currElement = matrix[currRow][currCol];

        while(currRow < matrix.length-1 || currCol >= 0){

            currElement = matrix[currRow][currCol];

            if(currElement == target){
                System.out.println("Element found at index --->  (" + currRow + ", " +currCol + ")");
                return;
            }
            if(target < currElement){      // Move Left
                currCol -= 1;
            }
            if(target>currElement){        // Move Down
                currRow +=1;
            }
        }
        System.out.println("Element Not Found");
    }
    

    public static void main(String[] args){
        int[][] matrix = {{10,20,30,40}, {15,25,35,45}, {27,29,37,48}, {32,33,39,50}};
        int target = 33;
        findElement(matrix, target);
    }
}
