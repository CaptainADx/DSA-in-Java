
public class callByReference {

    public static void update(int arr[], int count) {
        count = 10;
        for (int i = 0; i < arr.length; i++) {
            arr[i] += 1;
        }
    }

    public static void main(String[] args) {
        int arr[] = { 97, 95, 94 };/* This value will change  */
        int count = 5; /*  This value won't change after passing to a fuctions because it is a Primitive 
                           Data type.  */
        update(arr, count);

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }

        System.out.println(count);
    }
}